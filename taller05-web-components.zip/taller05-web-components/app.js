import "./components/profile-card.js";
import "./components/course-card.js";
import "./components/product-card.js";

console.log("Componentes cargados modulares");

class StudentCard extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    getStatus(grade) {
        if (grade >= 16) return "Destacado";
        if (grade >= 14) return "Aprobado";
        return "Riesgo";
    }

    render() {
        const name = this.getAttribute("name");
        const career = this.getAttribute("career");
        const level = this.getAttribute("level");
        const grade = Number(this.getAttribute("grade"));
        const status = this.getStatus(grade);

        this.innerHTML = `
            <article class="student-card">
                <h2>${name}</h2>
                <p><strong>Carrera:</strong> ${career}</p>
                <p><strong>Nivel:</strong> ${level}</p>
                <p><strong>Nota:</strong> ${grade}</p>
                <p><strong>Estado:</strong> ${status}</p>
                <button>Mostrar información</button>
            </article>
        `;

        this.querySelector("button").addEventListener("click", () => {
            alert(`Estudiante: ${name}\nPromedio: ${grade}\nEstado: ${status}`);
        });
    }
}
customElements.define("student-card", StudentCard);

class EmployeeCard extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
    }

    static get observedAttributes() {
        return ["name", "position", "department", "theme"];
    }

    connectedCallback() {
        this.render();
    }

    attributeChangedCallback(name, oldValue, newValue) {
        if (oldValue !== newValue) {
            this.render();
        }
    }

    render() {
        const name = this.getAttribute("name");
        const position = this.getAttribute("position");
        const department = this.getAttribute("department");
        const theme = this.getAttribute("theme") || "light";
        const isDark = theme === "dark";
        const bgColor = isDark ? "#1e293b" : "#f8fafc";
        const textColor = isDark ? "#f8fafc" : "#0f172a";
        const pColor = isDark ? "#cbd5e1" : "#475569";
        const badgeBg = isDark ? "#334155" : "#e2e8f0";
        const badgeText = isDark ? "#f1f5f9" : "#334155";
        const borderColor = isDark ? "#334155" : "#e2e8f0";

        this.shadowRoot.innerHTML = `
            <style>
                .employee-card {
                    border: 2px solid ${borderColor};
                    border-radius: 8px;
                    padding: 20px;
                    max-width: 300px;
                    background-color: ${bgColor};
                    font-family: Arial, sans-serif;
                    margin-bottom: 16px;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
                    transition: all 0.3s ease; /* Transición suave al cambiar de tema */
                }
                h2 {
                    color: ${textColor};
                    margin: 0 0 10px 0;
                    font-size: 1.4rem;
                }
                p {
                    color: ${pColor};
                    margin: 5px 0;
                    font-size: 1rem;
                }
                .department-badge {
                    display: inline-block;
                    margin-top: 8px;
                    padding: 4px 8px;
                    background-color: ${badgeBg};
                    color: ${badgeText};
                    border-radius: 4px;
                    font-size: 0.85rem;
                    font-weight: bold;
                }
            </style>
            
            <div class="employee-card">
                <h2>${name}</h2>
                <p><strong>Cargo:</strong> ${position}</p>
                <div class="department-badge">${department}</div>
            </div>
        `;
    }
}
customElements.define("employee-card", EmployeeCard);