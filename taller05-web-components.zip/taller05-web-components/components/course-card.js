const courseTemplate = document.createElement("template");
courseTemplate.innerHTML = `
    <style>
        .card {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 16px;
            max-width: 320px;
            font-family: Arial, sans-serif;
            background-color: #ffffff;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        ::slotted([slot="title"]) {
            color: #0284c7;
            margin-top: 0;
            font-size: 1.5rem;
        }
        .actions-zone {
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px dashed #cbd5e1;
        }
    </style>
    
    <article class="card">
        <header>
            <slot name="title"><h2>Título no disponible</h2></slot>
        </header>
        
        <section class="content">
            <slot name="description"><p>Sin descripción asignada.</p></slot>
        </section>
        
        <footer>
            <slot name="teacher"><span>Docente: Por definir</span></slot>
        </footer>

        <div class="actions-zone">
            <slot name="actions"></slot>
        </div>
    </article>
`;
export class CourseCard extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.shadowRoot.appendChild(courseTemplate.content.cloneNode(true));
    }
}
customElements.define("course-card", CourseCard);