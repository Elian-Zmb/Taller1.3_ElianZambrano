const template = document.createElement("template");
template.innerHTML = `
    <style>
        .card {
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            padding: 16px;
            max-width: 250px;
            font-family: Arial, sans-serif;
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        ::slotted([slot="name"]) {
            color: #0f172a;
            margin-top: 0;
            font-size: 1.3rem;
        }
        .price-tag {
            color: #16a34a;
            font-weight: bold;
            font-size: 1.2rem;
            margin-top: 12px;
        }
    </style>
    <article class="card">
        <!-- Primer slot -->
        <slot name="name"><h2>Producto Desconocido</h2></slot>
        
        <!-- Segundo slot -->
        <slot name="description"><p>Sin descripción del producto.</p></slot>
        
        <!-- Tercer slot -->
        <div class="price-tag">
            <slot name="price"><span>$0.00</span></slot>
        </div>
    </article>
`;

export class ProductCard extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.shadowRoot.appendChild(template.content.cloneNode(true));
    }
}

customElements.define("product-card", ProductCard);