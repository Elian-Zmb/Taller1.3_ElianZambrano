const profileTemplate = document.createElement("template");
profileTemplate.innerHTML = `
    <style>
        .card {
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 12px;
            padding: 16px;
            font-family: Arial, sans-serif;
            background-color: #f9fafb;
            margin-bottom: 20px;
        }
        .header {
            margin-bottom: 12px;
            color: #111827;
        }
        .content {
            color: #4b5563;
        }
        .footer {
            margin-top: 12px;
            font-size: 13px;
            color: #6b7280;
            border-top: 1px solid #e5e7eb;
            padding-top: 8px;
        }
    </style>
    <article class="card">
        <div class="header">
            <!-- Slot con nombre y contenido por defecto -->
            <slot name="name">
                <h2>Nombre no disponible</h2>
            </slot>
        </div>
        <div class="content">
            <!-- Slot con nombre y contenido por defecto -->
            <slot name="description">
                <p>Sin descripción</p>
            </slot>
        </div>
        <div class="footer">
            <!-- Slot con nombre (sin contenido por defecto, queda vacío si no se envía nada) -->
            <slot name="footer"></slot>
        </div>
    </article>
`;

export class ProfileCard extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.shadowRoot.appendChild(profileTemplate.content.cloneNode(true));
    }
}
customElements.define("profile-card", ProfileCard);